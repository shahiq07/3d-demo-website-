import * as THREE from 'three';

const mount = document.querySelector('#dish-canvas');
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(34, 1, 0.1, 100);
camera.position.set(0, 4.4, 8.7);
camera.lookAt(0, 0, 0);

const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'high-performance' });
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.7));
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.15;
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
mount.appendChild(renderer.domElement);

scene.add(new THREE.HemisphereLight(0xfff3d7, 0x5b3a1e, 2.0));
const keyLight = new THREE.DirectionalLight(0xffe7bd, 4.1);
keyLight.position.set(-4, 7, 5);
keyLight.castShadow = true;
scene.add(keyLight);
const rimLight = new THREE.PointLight(0xf1c66f, 62, 18);
rimLight.position.set(4, 2, -3);
scene.add(rimLight);

const dish = new THREE.Group();
scene.add(dish);

function material(color, roughness = 0.35, metalness = 0) {
  return new THREE.MeshStandardMaterial({ color, roughness, metalness });
}

function addMesh(geometry, mat, parent, position = [0, 0, 0], rotation = [0, 0, 0]) {
  const mesh = new THREE.Mesh(geometry, mat);
  mesh.position.set(...position);
  mesh.rotation.set(...rotation);
  mesh.castShadow = true;
  mesh.receiveShadow = true;
  parent.add(mesh);
  return mesh;
}

const brass = material(0xb47736, 0.25, 0.74);
const brassLight = material(0xd19a4e, 0.23, 0.68);
const darkCeramic = material(0x29271f, 0.22, 0.13);
const herb = material(0x526a32, 0.5);
const herbLight = material(0x849547, 0.46);

function addFlatRing(radius, thickness, segments, mat, position, depth = 1) {
  const geometry = new THREE.TorusGeometry(radius, thickness, 12, segments);
  geometry.rotateX(Math.PI / 2);
  const ring = addMesh(geometry, mat, dish, position);
  ring.scale.z = depth;
  return ring;
}

const platter = addMesh(new THREE.CylinderGeometry(2.3, 2.13, 0.2, 96), brass, dish, [0, -0.4, 0]);
platter.scale.z = 0.72;
const platterWell = addMesh(new THREE.CylinderGeometry(2.12, 2.18, 0.035, 96), darkCeramic, dish, [0, -0.28, 0]);
platterWell.scale.z = 0.72;
addFlatRing(2.13, 0.065, 96, brassLight, [0, -0.255, 0], 0.72);
addFlatRing(1.96, 0.018, 96, brass, [0, -0.25, 0], 0.72);

const studGeometry = new THREE.SphereGeometry(0.032, 10, 8);
for (let index = 0; index < 36; index++) {
  const angle = (index / 36) * Math.PI * 2;
  const stud = addMesh(studGeometry, brassLight, dish, [Math.cos(angle) * 2.13, -0.22, Math.sin(angle) * 1.51]);
  stud.scale.set(1, 0.42, 1);
}

function addKatori(x, z, radius, fillingColor, garnishColor, seed) {
  const profile = [
    new THREE.Vector2(0.01, -0.03), new THREE.Vector2(radius * 0.52, -0.03),
    new THREE.Vector2(radius * 0.83, 0.015), new THREE.Vector2(radius, 0.13),
    new THREE.Vector2(radius * 0.98, 0.23), new THREE.Vector2(radius * 0.88, 0.25),
    new THREE.Vector2(radius * 0.76, 0.16), new THREE.Vector2(radius * 0.58, 0.09),
    new THREE.Vector2(0.01, 0.08)
  ];
  const katori = addMesh(new THREE.LatheGeometry(profile, 40), brass, dish, [x, -0.24, z]);
  katori.scale.z = 0.84;

  const filling = material(fillingColor, 0.32, 0.02);
  const surface = addMesh(new THREE.CylinderGeometry(radius * 0.7, radius * 0.74, 0.025, 36), filling, dish, [x, -0.01, z]);
  surface.scale.z = 0.84;
  addFlatRing(radius * 0.91, 0.028, 40, brassLight, [x, 0.01, z], 0.84);

  const accent = material(garnishColor, 0.36);
  for (let index = 0; index < 3; index++) {
    const angle = seed + index * Math.PI * 2 / 3;
    const garnish = addMesh(new THREE.SphereGeometry(0.035, 12, 8), accent, dish, [x + Math.cos(angle) * radius * 0.31, 0.015, z + Math.sin(angle) * radius * 0.31]);
    garnish.scale.set(1.4, 0.32, 0.8);
  }
}

[
  [-1.26, -0.76, 0.37, 0x9d371d, 0x719044], [0, -1.18, 0.35, 0xd8c290, 0x526a32],
  [1.26, -0.76, 0.37, 0xd39a36, 0x526a32], [-1.47, 0.12, 0.36, 0x71834a, 0xd1a54e],
  [1.47, 0.12, 0.36, 0x9f4a29, 0xd5b76c], [-1.18, 0.94, 0.34, 0xd9c795, 0x698240],
  [0, 1.24, 0.34, 0x963b20, 0x79934b], [1.18, 0.94, 0.34, 0xc47b2e, 0x58723b]
].forEach(([x, z, radius, fillingColor, garnishColor], index) => {
  addKatori(x, z, radius, fillingColor, garnishColor, index * 0.7);
});

const rice = material(0xf0dfb0, 0.72);
const riceMound = addMesh(new THREE.SphereGeometry(1, 32, 24), rice, dish, [0, -0.16, 0]);
riceMound.scale.set(0.62, 0.25, 0.48);

const grainGeometry = new THREE.SphereGeometry(0.034, 8, 6);
for (let index = 0; index < 34; index++) {
  const angle = index * 2.39996;
  const radius = 0.08 + 0.43 * Math.sqrt((index + 0.5) / 34);
  const x = Math.cos(angle) * radius;
  const z = Math.sin(angle) * radius * 0.78;
  const height = -0.16 + 0.25 * Math.sqrt(Math.max(0, 1 - (x * x) / 0.3844 - (z * z) / 0.2304));
  const grain = addMesh(grainGeometry, rice, dish, [x, height + 0.018, z], [0.2, angle, 0.35]);
  grain.scale.set(0.55, 0.45, 1.45);
}

const chili = addMesh(new THREE.CapsuleGeometry(0.06, 0.46, 5, 12), material(0x69823c, 0.38), dish, [0.02, 0.1, 0.02], [0.3, 0.1, -0.72]);
chili.scale.set(0.8, 0.6, 0.58);
const tomato = addMesh(new THREE.SphereGeometry(0.12, 18, 14), material(0xb63e28, 0.34), dish, [-0.34, -0.015, 0.1]);
tomato.scale.set(1.25, 0.45, 0.9);
[-0.45, 0.38, 0.43].forEach((angle, index) => {
  const leaf = addMesh(new THREE.SphereGeometry(0.1, 14, 10), index % 2 ? herbLight : herb, dish, [Math.cos(angle) * 0.22, 0.035, Math.sin(angle) * 0.16], [0, angle, angle * 0.4]);
  leaf.scale.set(0.42, 0.1, 1.35);
});

dish.rotation.x = -0.12;
dish.rotation.y = -0.25;

const pointer = { down: false, x: 0, rotation: 0 };
mount.addEventListener('pointerdown', event => {
  pointer.down = true;
  pointer.x = event.clientX;
  mount.setPointerCapture(event.pointerId);
});
mount.addEventListener('pointermove', event => {
  if (!pointer.down) return;
  pointer.rotation += (event.clientX - pointer.x) * 0.009;
  pointer.x = event.clientX;
});
mount.addEventListener('pointerup', () => { pointer.down = false; });
mount.addEventListener('pointercancel', () => { pointer.down = false; });

function resize() {
  const width = Math.max(mount.clientWidth, 1);
  const height = Math.max(mount.clientHeight, 1);
  renderer.setSize(width, height, false);
  camera.aspect = width / height;
  camera.position.set(0, 4.4, width < 500 ? 10.1 : 8.7);
  camera.lookAt(0, 0, 0);
  camera.updateProjectionMatrix();
}
new ResizeObserver(resize).observe(mount);
resize();

const clock = new THREE.Clock();
function animate() {
  const elapsed = clock.getElapsedTime();
  if (!pointer.down) pointer.rotation += 0.0016;
  dish.rotation.y = pointer.rotation - 0.25;
  dish.position.y = Math.sin(elapsed * 1.2) * 0.07;
  renderer.render(scene, camera);
  requestAnimationFrame(animate);
}
animate();